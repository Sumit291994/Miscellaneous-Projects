package com.example.chat1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap; 
import android.net.Uri; 
import android.provider.ContactsContract;
import android.provider.MediaStore;

public class number extends ActionBarActivity{
	public Thread mythread;
	TextView t2;
	EditText e1,e2;
	Button b1,b2;
	String s,msg,l,p,k;
	String phone= null;
	HttpClient client;
	 HttpGet get;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.number_activity);

		e1=(EditText)findViewById(R.id.editText1);
		e2=(EditText)findViewById(R.id.editText2);
		t2=(TextView)findViewById(R.id.textView2);
		b1=(Button)findViewById(R.id.button1);
		b2=(Button)findViewById(R.id.button2);
		
		
		
		Typeface custom_font = Typeface.createFromAsset(getAssets(), "fonts/GoodDog/GoodDog.otf");
		Typeface custom_font2= Typeface.createFromAsset(getAssets(), "fonts/Quicksand-Italic.otf");
		Typeface custom_font3= Typeface.createFromAsset(getAssets(), "fonts/Pacifico.ttf");
		e2.setTypeface(custom_font);
		e1.setTypeface(custom_font);
		t2.setTypeface(custom_font);
		b2.setTypeface(custom_font2);
		e2.setText("KEEP CALM AND ENTER TEXT!!");
		b2.setText("...............SEND..................");
		
		b1.setOnClickListener(
				   
				   new OnClickListener() {
					
					@Override
					public void onClick(View arg0) {
						 	
					        		
					        		
						s=(e1.getText().toString());
						//t2.setText(s);       		
					        		
					        		
						readContacts();
					        
						
					}
				}
				   );
	
		b2.setOnClickListener(
				   
				   new OnClickListener() {
					
					@Override
					public void onClick(View arg0) {
						
						msg=(e2.getText()).toString();
						p=p.replaceAll("\\s","");
						msg=msg.replaceAll("\\s","%20");
						e1.setText("name:"+s+" no:"+p); 
						 k="http://msg.bricsworld.com/?uname=brics&paswd=brics&mobile=";
			    	     k= k.concat(p);
			    	     k= k.concat("&msg=");
			    	     k= k.concat(msg);
			    	     e2.setText(k);
						
						mythread=new Thread(){
				    	    public void run(){
				    	
				    	    	try{ 	    
				    	    		//phone=p.toString();
				    	    		
				    	    client = new DefaultHttpClient();
				    	  
				    	     e2.setText("");
				    	     
				    		get = new HttpGet(k);
				    	    	}catch(Exception e){
				    	    		e.printStackTrace();
				    	    	}
				    	    	
				    	    	
				    	  //  HttpGet post = new HttpGet("http://msg.bricsworld.com/?uname=brics&paswd=brics&mobile="+phone+"&msg"+msg);
				    	    
				    	    
				   /* 	    List<NameValuePair> pairs = new ArrayList<NameValuePair>();
				    	    pairs.add(new BasicNameValuePair("a",s));
				    	    pairs.add(new BasicNameValuePair("b",p));
				    	    pairs.add(new BasicNameValuePair("c",msg));
				    	     try {
				    			post.setEntity(new UrlEncodedFormEntity(pairs));
				    		} catch (UnsupportedEncodingException e) {
				    			// TODO Auto-generated catch block
				    			e.printStackTrace();
				    		}
				    	    */
				    	    try {
				    	    	HttpResponse response = client.execute(get);
				    	    //	HttpResponse response = client.execute(post);
				    	    	
				    	    	BufferedReader br=new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				    	    	  l=br.readLine();
				    		 s=response.toString();
				    		// e2.setText(s);
				    		runOnUiThread(new Runnable() {
								
								@Override
								public void run() {
									// TODO Auto-generated method stub
						//	Toast.makeText(getApplicationContext(), "MESSAGE SENT", 1).show();
									Toast.makeText(getApplicationContext(),s, 1).show();
								}
							});
				    		} catch (final Exception e) {
				    			// TODO Auto-generated catch block
				    			e.printStackTrace();
				    			runOnUiThread(new Runnable() {
				    				
				    				@Override
				    				public void run() {
				    					// TODO Auto-generated method stub
				  					Toast.makeText(getApplicationContext(), e.toString(), 1).show();
				    				}
				    			});
				    			
				    		}
				    	    }
				    				};
				        mythread.start();
						 	
					        		
					        		
						
					        
						
					}
				}
				   );
	

		
		
		
	}

	private void readContacts() {
		// TODO Auto-generated method stub
		StringBuffer sb = new StringBuffer();
		 sb.append("......Contact Details....."); 
		ContentResolver cr = getContentResolver(); 
		Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null); 
	//	String phone = null; 
		String emailContact = null;
		 String emailType = null;
		 String image_uri = ""; 
		Bitmap bitmap = null; 
		
		if (cur.getCount() > 0) 
		{
			
			
				while (cur.moveToNext())
				{ 
		   String id = cur.getString(cur .getColumnIndex(ContactsContract.Contacts._ID)); 
			String name = cur .getString(cur .getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
//		image_uri = cur .getString(cur .getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_URI)); 
			if(s.equalsIgnoreCase(name))
			{
				if (Integer .parseInt(cur.getString(cur .getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0)
				{ System.out.println("name : " + name ); sb.append("\n Contact Name:" + name);
				Cursor pCur = cr.query( ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?", new String[] { id }, null); 
			
				while (pCur.moveToNext())
				{
					phone = pCur .getString(pCur .getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
				sb.append("\n Phone number:" + phone);
				p=phone;
				System.out.println("phone" + phone); 
				} 
				pCur.close(); 
				/*Cursor emailCur = cr.query( ContactsContract.CommonDataKinds.Email.CONTENT_URI, null, ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = ?", new String[] { id }, null); 
				while (emailCur.moveToNext())
				{ 
					emailContact = emailCur .getString(emailCur .getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA));
				emailType = emailCur .getString(emailCur .getColumnIndex(ContactsContract.CommonDataKinds.Email.TYPE));
				sb.append("\nEmail:" + emailContact + "Email type:" + emailType); 
				System.out.println("Email " + emailContact + " Email Type : " + emailType); 
				} 
				emailCur.close(); */
				}
				/*if (image_uri != null) 
				{ System.out.println(Uri.parse(image_uri));
				try { bitmap = MediaStore.Images.Media .getBitmap(this.getContentResolver(), Uri.parse(image_uri));
				sb.append("\n Image in Bitmap:" + bitmap); System.out.println(bitmap);
				} catch (FileNotFoundException e) 
				{ // TODO Auto-generated catch block 
					e.printStackTrace(); } 
				catch (IOException e) { // TODO Auto-generated catch block
					e.printStackTrace(); } } */
				sb.append("\n...");
				}
				t2.setText(sb);
			}
			
			 } 
			}
			
			}
		
		
	


