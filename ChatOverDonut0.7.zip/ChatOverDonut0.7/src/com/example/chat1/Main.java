package com.example.chat1;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Main extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gamemainpage);
       final Button b1=(Button)findViewById(R.id.button1);
       
       final Button b2=(Button)findViewById(R.id.button2);
       
       
       b1.setOnClickListener(
    		   
    		   new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					 Thread newthtead =new Thread(){
				        	public void run(){
			        						        	
				        		Intent intent5 = new Intent("android.intent.action.Game");
				        		startActivity(intent5);
				        		
				        		
				        	 }
				        };
				        
				        newthtead.start();
				        
					
				}
			}
    		   );
       b2.setOnClickListener(
    		   
    		   new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					 Thread newthtead =new Thread(){
				        	public void run(){
			        						        	
				        		Intent intent6 = new Intent("android.intent.action.snakeActivity");
				        		startActivity(intent6);
				        		
				        		
				        	 }
				        };
				        
				        newthtead.start();
				        
					
				}
			}
    		   );
       
    }
}
