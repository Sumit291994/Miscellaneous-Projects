package com.example.chat1;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class b extends ActionBarActivity{
	ListView mylistv;
	Button button,b2,b3,b4;
	EditText e1;
	ArrayAdapter<String> mylist;
	BluetoothAdapter btadapter;
	Set<BluetoothDevice> btlist;
	BroadcastReceiver myreceiver;
	BluetoothDevice mmdevice;
	BluetoothSocket mmSocket;
	BluetoothDevice mmDevice;
	int count=0;
	public ConnectThread T1;
	ConnectedThread T2; 
	public AcceptThread T3;
	String ss;
	 ArrayAdapter<String> mConversationArrayAdapter;
		
 final UUID SerialPortServiceClass_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.b_activity);
		mylistv=(ListView)findViewById(R.id.ListView1);
		button =(Button)findViewById(R.id.button1);
		b2 =(Button)findViewById(R.id.button2);
		b3 =(Button)findViewById(R.id.button3);
		b4 =(Button)findViewById(R.id.button4);
        e1=(EditText)findViewById(R.id.editText1);
       mylist= new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
       mylistv.setAdapter(mylist);
        
btadapter= BluetoothAdapter.getDefaultAdapter();
		
		
Typeface custom_font = Typeface.createFromAsset(getAssets(), "fonts/GoodDog/GoodDog.otf");
e1.setTypeface(custom_font);
button.setTypeface(custom_font);
b2.setTypeface(custom_font);
b3.setTypeface(custom_font);
b4.setTypeface(custom_font);
button.setText("SEND MSG");
b2.setText("DISCONNECT");
b3.setText("ACCEPT");
b4.setText("SEND IMAGE");
		
		myreceiver =new BroadcastReceiver() {
			
			@Override
			public void onReceive(Context arg0, Intent arg1) {
				// TODO Auto-generated method stub
				
			}
		};
		
		
        
        if(btadapter==null){
			Toast.makeText(getApplicationContext(), "no Bluetooth Available ", 1).show();
			finish();
		}else{
			if(!btadapter.isEnabled()){
				Intent intent = new Intent (btadapter.ACTION_REQUEST_ENABLE);
				startActivityForResult(intent,1);	
			}
			
			btlist= btadapter.getBondedDevices();
			if(btlist.size()>0){
				for(BluetoothDevice onebt:btlist){
					mylist.add(onebt.getName());
					
				}
			}
			
			
		}
        
        
        button.setOnClickListener(
				   
				   new OnClickListener() {
					
					@Override
					public void onClick(View arg5) {
						Toast.makeText(getApplicationContext(), "SENDING TO:-"+mmdevice.getName(), 1).show();
						
						T2.write(((e1.getText()).toString()+"\r\n").getBytes());
						
						 	
					}
				   });
        
        
        
        b2.setOnClickListener(
				   
				   new OnClickListener() {
					
					@Override
					public void onClick(View arg5) {
						T1.cancel();
						//Toast.makeText(getApplicationContext(), "ENDING CONNECTION ", 1);
						e1.setText("ENDED CONNECTION ..SELECT DEVICE TO SEND AGAIN");
						
						 	
					}
				   });
        
        b4.setOnClickListener(
				   
				   new OnClickListener() {
					
					@Override
					public void onClick(View arg7) {
						try
						{
							Intent intentV=new Intent("android.intent.action.Gallery");
							startActivity(intentV);
						}
						catch(Exception e)
						{
							//t1.setText("soryyy");
						}
						
						
						
						 	
					}
				   });
        
        
        b3.setOnClickListener(
				   
				   new OnClickListener() {
					
					@Override
					public void onClick(View arg5) {
					//	Toast.makeText(getApplicationContext(), "accepting CONNECTION TO:-"+mmdevice.getName(), 1).show();
						//e1.setText("yooooo");
					//	Toast.makeText(getApplicationContext(), "accepting CONNECTION TO AVAILABLE DEVICE", 1);
						
						try{ 
							
							T3= new AcceptThread();
								T3.start();
								Toast.makeText(getApplicationContext(), "searching for connection", 1);
								while(mmSocket==null){}
								T2= new ConnectedThread(mmSocket);
									T2.start();
					
								Toast.makeText(getApplicationContext(), "connection started", 1).show();
							
								
							}catch(Exception e)
							{
								Toast.makeText(getApplicationContext(),"sorryyy.."+e.toString(), 1).show();
							}
						 	
					}
				   });
     
        
        mylistv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				

				count=0;
				for(BluetoothDevice onebt:btlist){
				
					if (count==arg2)
					{mmdevice=onebt;
					Toast.makeText(getApplicationContext(), "Your selected device is-"+mmdevice.getName(), 1).show();
					try{ 
					T1= new ConnectThread(mmdevice);
						T1.start();
						
						
						T2= new ConnectedThread(mmSocket);
							T2.start();
					}catch(Exception e)
					{
						Toast.makeText(getApplicationContext(),e.toString(), 1).show();
					}
					
					break;
					}
					count++;
					
					
			}
				Toast.makeText(getApplicationContext(), "Press button to send", 1).show();
				
			//	T2.start();
				
				
		};
		});
        
	}
	 
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if(requestCode==RESULT_CANCELED){
			Toast.makeText(getApplicationContext(), "Switch on bluetooth and try again", 1).show();
			finish();
		}	
		else
		{
			Toast.makeText(getApplicationContext(), "success!SELECT DEVICE and continue", 1).show();
			btlist= btadapter.getBondedDevices();
			if(btlist.size()>0){
				for(BluetoothDevice onebt:btlist){
					mylist.add(onebt.getName());
					
				}
			}
			
		}
		
		
		
}
	

	private class AcceptThread extends Thread {
		private final BluetoothServerSocket mmServerSocket;

		public AcceptThread() {
			/*BluetoothServerSocket tmp = null;
			try {
				BluetoothAdapter mBluetoothAdapter = null;
				tmp = mBluetoothAdapter.listenUsingRfcommWithServiceRecord(
						"BRiCS", SerialPortServiceClass_UUID);
			} catch (IOException e) {
			}
			mmServerSocket = tmp;*/
			BluetoothServerSocket tmp2 = null;
			try {
				tmp2 = btadapter.listenUsingRfcommWithServiceRecord("BRiCS", SerialPortServiceClass_UUID);
			} catch (IOException e) {
			}
			mmServerSocket = tmp2;
		}

		public void run() {
			BluetoothSocket socket = null;
			while (true) {
				try {
					socket = mmServerSocket.accept();
				} catch (IOException e) {
					break;
				}
			 mmSocket = socket;
				if (socket != null) {
					break;
				}
			}
		}

		/** Will cancel the listening socket, and cause the thread to finish */
		public void cancel() {
			try {
				mmServerSocket.close();
			} catch (IOException e) {
			}
		}
	}

	
	
	
	
	public class ConnectThread extends Thread {
		//private  BluetoothSocket mmSocket;
	//    private final BluetoothDevice mmDevice;
	 
	    public ConnectThread(BluetoothDevice device) {
	        BluetoothSocket tmp = null;
	        mmDevice = device;
	        try {
	            tmp = device.createRfcommSocketToServiceRecord(SerialPortServiceClass_UUID);
	        } catch (IOException e) {	Toast.makeText(getApplicationContext(),e.toString(), 1).show(); }
	        mmSocket = tmp;
	    }
	 
	    public void run() {
	        btadapter.cancelDiscovery();
	 
	        try {
	            mmSocket.connect();
	        } catch (IOException connectException) {
	            try {
	                mmSocket.close();
	            } catch (IOException closeException) { }
	            return;
	        }
	    }
	 
	    /** Will cancel an in-progress connection, and close the socket */
	   public void cancel() {
	        try {
	            mmSocket.close();
	        } catch (IOException e) { }
	    }
	}
	
	
	public class ConnectedThread extends Thread {
	 //   private final BluetoothSocket mmSocket;
	    private final InputStream mmInStream;
	    private final OutputStream mmOutStream;
	 
	    @SuppressLint("NewApi")
		public ConnectedThread(BluetoothSocket socket) {
	        mmSocket = socket;
	        InputStream tmpIn = null;
	        OutputStream tmpOut = null;
			while(!mmSocket.isConnected()){};
	        try {
	            tmpIn = socket.getInputStream();
	            tmpOut = socket.getOutputStream();
	        } catch (IOException e) { Toast.makeText(getApplicationContext(),e.toString(), 1).show();}
	 
	        mmInStream = tmpIn;
	        mmOutStream = tmpOut;
	    }
	 
	    public void run() {
	        byte[] buffer = new byte[1024];  // buffer store for the stream
	        int bytes; // bytes returned from read()
	     
	        while (true) {
	           // T2.start();
	        	try {
	        		
	                bytes = mmInStream.read(buffer);
	                
	               ss="";
	            
	                if(bytes>0)
	                { ss = ss+new String(buffer,0,bytes);
	              runOnUiThread(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						e1.setText(ss);
						 Toast.makeText(getApplicationContext(), "MSG recieved!!"+ss, 1).show();
					}
				});
	                
	               
	                
	                }
	                
	            } catch (IOException e) {
	            //	Toast.makeText(getApplicationContext(), e.toString(), 1).show();
	                break;
	            }
	        }
	    }
	 
	    public void write(byte[] bytes) {
	        try {
	            mmOutStream.write(bytes);
	        } catch (IOException e) { 
	
	        }
	    }
	    public void cancel() {
	        try {
	            mmSocket.close();
	        } catch (IOException e) { }
	    }
	}
	    
	
}
