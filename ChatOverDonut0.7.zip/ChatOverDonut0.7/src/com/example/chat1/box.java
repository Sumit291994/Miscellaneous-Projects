package com.example.chat1;

public class box {
public 	int dx,dy,status;
box head;

public box(int i, int j, int k) {
	// TODO Auto-generated constructor stub
	this.dx=i;
	this.dy=j;
	this.status=k;
}




}
