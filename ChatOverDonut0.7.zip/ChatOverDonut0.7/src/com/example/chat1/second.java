package com.example.chat1;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class second extends ActionBarActivity{
	public float dest;
	public ImageView aniView;
	public Button b4,b5;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.second_activity);

	//	final EditText e1=(EditText)findViewById(R.id.editText1);
		
		
		final Button b1=(Button)findViewById(R.id.button1);
		final Button b2=(Button)findViewById(R.id.button2);
		final Button b3=(Button)findViewById(R.id.button3);
		 b4=(Button)findViewById(R.id.button4);
		 b5=(Button)findViewById(R.id.button5);
		
		final TextView t1=(TextView)findViewById(R.id.textView1);
		
		Typeface custom_font = Typeface.createFromAsset(getAssets(), "fonts/GoodDog/GoodDog.otf");
		Typeface custom_font2 = Typeface.createFromAsset(getAssets(), "fonts/Quicksand-Italic.otf");
		t1.setTypeface(custom_font);
		b1.setTypeface(custom_font);
		b2.setTypeface(custom_font);
		b3.setTypeface(custom_font);
		b5.setTypeface(custom_font);
		b1.setText("via messaging");
		b2.setText("via bluetooth");
		b3.setText("Lets Play");
		b5.setText("via mail");
		t1.setText("HOW will you chat today?");
		
		
		b1.setOnClickListener(
				   
				   new OnClickListener() {
					
					@Override
					public void onClick(View arg0) {
						 	
					        		
					        		
					        		try
									{
										Intent intent2=new Intent("android.intent.action.number");
										startActivity(intent2);
					        			//Intent intent3=new Intent("android.intent.action.b");
										//startActivity(intent3);
									}
									catch(Exception e)
									{
									t1.setText("soryyy");
									}
									
					        		
					        		
					      
					        
						
					}
				}
				   );

		b2.setOnClickListener(
				   
				   new OnClickListener() {
					
					@Override
					public void onClick(View arg1) {
						 	
					        		
					        		
					        		try
									{
										Intent intent3=new Intent("android.intent.action.b");
										startActivity(intent3);
									}
									catch(Exception e)
									{
										//t1.setText("soryyy");
									}
									
					        		
					        		
					      
					        
						
					}
				}
				   );
		b3.setOnClickListener(
				   
				   new OnClickListener() {
					
					@Override
					public void onClick(View arg1) {
						 	
					        		
					        		
					        		try
									{
										Intent intent4=new Intent("android.intent.action.Main");
										startActivity(intent4);
									}
									catch(Exception e)
									{
										//t1.setText("soryyy");
									}
									
					        		
					        		
					      
					        
						
					}
				}
				   );
		
		b5.setOnClickListener(
				   
				   new OnClickListener() {
					
					@Override
					public void onClick(View arg1) {
						 	
					        		
					        		
					        		try
									{
										Intent intent5=new Intent("android.intent.action.mail");
										startActivity(intent5);
									}
									catch(Exception e)
									{
										//t1.setText("soryyy");
									}
									
					        		
					        		
					      
					        
						
					}
				}
				   );

		
	}
	@SuppressLint("NewApi")
	public void startAnimation(View view){
		dest = 0;
	     aniView = (ImageView) findViewById(R.id.imageView1);
	    switch (view.getId()) {
	    case R.id.button4:
	        dest = 360;
	        if (aniView.getRotation() == 360) {
	          System.out.println(aniView.getAlpha());
	          dest = 0;
	        }
	        ObjectAnimator animation1 = ObjectAnimator.ofFloat(aniView,"rotation", dest);
	        animation1.setDuration(2000);
	        animation1.start();
	          break;
	    default:
	    	break;

	    }	
	}
	
	 @Override
	  public boolean onCreateOptionsMenu(Menu menu) {
	    getMenuInflater().inflate(R.menu.main, menu);
	    return super.onCreateOptionsMenu(menu);
	  }
	@Override
	  public boolean onOptionsItemSelected(MenuItem item) {
	    Intent intent = new Intent(this, HitActivity.class);
	    startActivity(intent);
	    return true;
	  }

}
