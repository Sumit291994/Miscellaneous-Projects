package com.example.chat1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.MediaStore.Images.Media;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Gallery extends ActionBarActivity {
	public static final int SELECT_PICTURE = 1;
	 public ImageView img; 
	 Uri selectedImage                     = null;
	 public Button b1;
	 public TextView t1;
		String s1,s2,s3,s4,s5;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_gallery);

		if (savedInstanceState == null) {
			getSupportFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
		}
		
		 View.OnClickListener mylist;
		 b1=(Button)findViewById(R.id.button1);
		// t1=(TextView)findViewById(R.id.textView1);
		img = (ImageView) findViewById(R.id.imageView1);

		b1.setOnClickListener(new Button.OnClickListener(){

		    public void onClick(View v) {
		              if(v.getId()==R.id.button1)
		              {      //do something
		            	
		            	  b1.setText("y"); 
		            	  

		           // 	 File file = new File("\\SD Card\\DCIM\\100ANDRO"+"\\DSC_3445.JPG");
		            //	 String s2=Environment.getExternalStorageDirectory().
			  		//	            getPath();
		            //	 t1.setText(s2);
		  			     try{  Intent i = new Intent(android.content.Intent.ACTION_SEND);
		  			        i.setType("image/*");
		  			      /*  i.setComponent(
		  			            new ComponentName("com.android.bluetooth",                         
		  			   "com.android.bluetooth.opp.BluetoothOppLauncherActivity"));*/
		  			      
		  			      i.putExtra(Intent.EXTRA_STREAM, selectedImage);
		  			        startActivity(i);}
		  			        catch(Exception e){
		  			        	b1.setText(e.toString());}
		  			        }
		                  
		    }   });
		
		
	
		
		 Intent pickIntent = new Intent();
		  pickIntent.setType("image/*");
		  pickIntent.setAction(Intent.ACTION_GET_CONTENT);
		 
		  // Intent for camera activity to capture a new picture
		  Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		 
		  // Title of the popup
		  String pickTitle = "Choose a Picture";
		  Intent chooserIntent = Intent.createChooser(pickIntent, pickTitle);
		  chooserIntent.putExtra
		          (
		                  Intent.EXTRA_INITIAL_INTENTS,
		                  new Intent[]{takePhotoIntent}
		          );
		 
		  startActivityForResult(chooserIntent, SELECT_PICTURE);
		
	}
	
	protected void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
	    super.onActivityResult(requestCode, resultCode, imageReturnedIntent);
	    switch (requestCode) {
	        case SELECT_PICTURE:
	            if (resultCode == RESULT_OK) {
	            	
	                 selectedImage = imageReturnedIntent.getData();
	         //       File f = new File("" + selectedImage);

	           //  s1=  f.getName()+".JPG";
 //s1=selectedImage.toString();	 
 //t1.setText(s1);
	                ((ImageView)findViewById(R.id.imageView1)).setImageURI(selectedImage);
	                
	            }
	            break;
	    }
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.gallery, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_gallery,
					container, false);
			return rootView;
		}
	}

}
